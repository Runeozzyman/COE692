package business;

import helper.SongsXML; 
import java.util.ArrayList;
import java.util.List;
import persistence.song_CRUD; 
import helper.Song; 

public class SongService {

    public SongsXML getAllSongs() {
        List<Song> songs = song_CRUD.getSongs(); 
        SongsXML songsXML = new SongsXML(); 
        songsXML.setSong(songs);
        return songsXML;
    }
    
    public SongsXML getUserSongs() {
        List<Song> songs = song_CRUD.getSongsByUserID(); 
        SongsXML songsXML = new SongsXML(); 
        songsXML.setSong(songs);
        return songsXML;
    }

 
}
