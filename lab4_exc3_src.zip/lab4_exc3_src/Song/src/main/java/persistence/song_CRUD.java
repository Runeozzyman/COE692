package persistence;

import helper.Song;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class song_CRUD {

    public static List<Song> getSongs() {
        List<Song> songs = new ArrayList<>();
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = getCon();
            String q = "SELECT * FROM songs"; 
            ps = con.prepareStatement(q);
            rs = ps.executeQuery();

            while (rs.next()) {
                String sName = rs.getString("song_name");
                String sArtist = rs.getString("artist_name");
                Song song = new Song(sName, sArtist);
                songs.add(song);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return songs;
    }
    
    
    public static List<Song> getSongsByUserID() {
    List<Song> songs = new ArrayList<>();
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    
   
    
    try {
        con = getCon();
        String q = "SELECT * FROM song WHERE userID = 1";
        ps = con.prepareStatement(q);
        rs = ps.executeQuery();

        while (rs.next()) {
            String sName = rs.getString("song_name");
            String sArtist = rs.getString("artist_name");
            Song song = new Song(sName, sArtist);
            songs.add(song);
        }
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    return songs;
}


    private static Connection getCon() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/songs?autoReconnect=true&useSSL=false", "root", "student");
            System.out.println("Connection established");
        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }
    
    
    
}



