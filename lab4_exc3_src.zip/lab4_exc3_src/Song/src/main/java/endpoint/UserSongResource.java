package endpoint;

import java.io.StringWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.ws.rs.FormParam;
import javax.ws.rs.PathParam;

import business.SongService;
import helper.SongsXML;

@Path("UserSongs")
public class UserSongResource {

    public UserSongResource() {
    }

    @GET
    @Produces(MediaType.APPLICATION_XML + ";charset=utf-8")
    public String getUserSongsXml() {
        
        SongService songService = new SongService();
        SongsXML songs = songService.getUserSongs();
        
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(SongsXML.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            
            StringWriter sw = new StringWriter();
            jaxbMarshaller.marshal(songs, sw);
            
            return sw.toString();
        } catch (JAXBException ex) {
            Logger.getLogger(UserSongResource.class.getName()).log(Level.SEVERE, null, ex);
            return "<error>Error occurred while processing your request.</error>";
        }
    }
}
