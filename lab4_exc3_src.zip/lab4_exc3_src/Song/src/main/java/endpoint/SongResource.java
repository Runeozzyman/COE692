package endpoint;

import java.io.StringWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import business.SongService;
import helper.SongsXML;

@Path("songs")
public class SongResource {

    @Context
    private UriInfo context;

    public SongResource() {
    }

    @GET
    @Produces(MediaType.APPLICATION_XML + ";charset=utf-8")
    public String getSongsXml() {
        SongService songService = new SongService();
        SongsXML songs = songService.getAllSongs();
        
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(SongsXML.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            
            StringWriter sw = new StringWriter();
            jaxbMarshaller.marshal(songs, sw);
            
            return sw.toString();
        } catch (JAXBException ex) {
            Logger.getLogger(SongResource.class.getName()).log(Level.SEVERE, null, ex);
            return "error happened";
        }
    }
}
