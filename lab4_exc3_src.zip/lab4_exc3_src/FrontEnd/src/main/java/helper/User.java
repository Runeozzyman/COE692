package helper;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;

@XmlRootElement(name="User")
@XmlAccessorType(XmlAccessType.FIELD)  
public class User {
    
    public User(){}
    
    private int id;
    private String username, password;
    
    public User(int id,String username, String password){
        this.id = id;
        this.username = username;
        this.password = password;
        
    }
    
    public static String getUsername(User user){
        return user.username;
    }
    
    public static String getPass(User user){
        return user.password;
    }
}
