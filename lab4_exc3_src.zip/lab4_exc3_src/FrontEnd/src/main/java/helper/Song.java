package helper;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;

@XmlRootElement(name="song")
@XmlAccessorType(XmlAccessType.FIELD)        
public class Song {
 
    private String name, artist;
    
    public Song(String name, String artist){
        this.name = name;
        this.artist = artist;
        
    }
    
    public Song() {}
    
    public String getName(){
        return this.name;
    }
    
    public void setName(String name){
        this.name = name;
    }
    
    public String getArtist(){
        return this.artist;
    }
    
    public void setArtist(String artist){
        this.artist = artist;
    }
}
