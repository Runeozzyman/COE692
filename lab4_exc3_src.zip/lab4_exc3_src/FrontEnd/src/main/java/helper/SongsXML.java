package helper;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "songs") 
@XmlAccessorType(XmlAccessType.FIELD)
public class SongsXML {
    @XmlElement(name = "song") 
    private List<Song> songs;

    public SongsXML() {}

    public List<Song> getSongs() {
        return songs;
    }

    public void setSong(List<Song> bs) { 
        this.songs = bs;
    }
}
