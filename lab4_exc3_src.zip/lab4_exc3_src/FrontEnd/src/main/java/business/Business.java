package business;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import helper.Song;
import helper.User;
import helper.UserXML;
import helper.SongsXML;
import org.apache.commons.io.IOUtils;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.util.List;




public class Business {
    
     public static boolean isAuthenticated(String username, String passwrod) {
        return true;
    }
    
    public static boolean verifyUser(List<User> users, String username, String password) {
       
        
        for (User user : users) {
            
            if (User.getUsername(user).equals(username) && User.getPass(user).equals(password)) {
                return true; 
            }
        }
        return false; 
    }
     

    public static SongsXML getSongs(String query) throws IOException {
    
    Client searchClient = ClientBuilder.newClient();
    
    WebTarget searchWebTarget = searchClient.target("http://localhost:8080/Song/webresources/songs");

    
    InputStream is = searchWebTarget.request(MediaType.APPLICATION_XML).get(InputStream.class);
    
    
    String xml = IOUtils.toString(is, "UTF-8");
    
    
    SongsXML songs = songsXmlToObjects(xml);

    
    return songs;
}
    
    public static SongsXML getUserSongs(int userID) throws IOException {
   
    Client searchClient = ClientBuilder.newClient();
    
    
    WebTarget searchWebTarget = searchClient.target("http://localhost:8080/Song/webresources/UserSongs");
    
    
    InputStream is = searchWebTarget.request(MediaType.APPLICATION_XML).get(InputStream.class);
    
    
    String xml = IOUtils.toString(is, "UTF-8");
    
    
    SongsXML songs = songsXmlToObjects(xml); 
    
    
    return songs;
}
    
public static UserXML getUsers() throws IOException {
    
    Client searchClient = ClientBuilder.newClient();
    
    WebTarget searchWebTarget = searchClient.target("http://localhost:8080/User/webresources/users");
    
    InputStream is = searchWebTarget.request(MediaType.APPLICATION_XML).get(InputStream.class);
    
    String xml = IOUtils.toString(is, "UTF-8");
   
    UserXML users = UserXmlToObject(xml);
 
    return users;
}
    
    
    private static SongsXML songsXmlToObjects(String xml) {
    JAXBContext jaxbContext;
    try {
        
        jaxbContext = JAXBContext.newInstance(SongsXML.class);

        
        Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

       
        SongsXML songs = (SongsXML) jaxbUnmarshaller.unmarshal(new StringReader(xml));
        return songs;

    } catch (JAXBException e) {
        e.printStackTrace();
    }
    return null;
}
    
     private static UserXML UserXmlToObject(String xml) {
        JAXBContext jaxbContext;
        try {
            
            jaxbContext = JAXBContext.newInstance(UserXML.class);

            
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

            
            return (UserXML) jaxbUnmarshaller.unmarshal(new StringReader(xml));

        } catch (JAXBException e) {
            e.printStackTrace();
        }
        return null;
    }
    
}
