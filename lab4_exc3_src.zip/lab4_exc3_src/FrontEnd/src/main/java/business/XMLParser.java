package business;


import java.io.StringReader;
import java.util.List;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import helper.User;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import java.io.StringReader;

public class XMLParser {

    public static String convertXmlToHtmlTable(String xml) {
        StringBuilder html = new StringBuilder();
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new InputSource(new StringReader(xml)));
            Element root = document.getDocumentElement();

            html.append("<table border=\"1\" cellpadding=\"5\" cellspacing=\"0\">");
            processNode(root, html); // Process the root node
            html.append("</table>");
        } catch (Exception e) {
            e.printStackTrace();
            
            return "<pre>" + xml + "</pre>";
        }
        return html.toString();
    }

     public static List<User> parseUserXML(String userXML) {
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(User.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            List<User> userList = (List<User>) jaxbUnmarshaller.unmarshal(new StringReader(userXML));
            return userList;
        } catch (JAXBException e) {
            e.printStackTrace();
            return null;
        }
    }
    
     public static boolean findUser(String xml, String username, String password) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new InputSource(new StringReader(xml)));
            Element root = document.getDocumentElement();
            NodeList userList = root.getElementsByTagName("user");

            for (int i = 0; i < userList.getLength(); i++) {
                Element userElement = (Element) userList.item(i);
                String storedUsername = userElement.getElementsByTagName("username").item(0).getTextContent();
                String storedPassword = userElement.getElementsByTagName("password").item(0).getTextContent();
                if (storedUsername.equals(username) && storedPassword.equals(password)) {
                    
                    return true;
                }
            }
            
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            
            return false;
        }
    }
    
    
    private static void processNode(Node node, StringBuilder html) {
        
        if (node.getNodeType() == Node.ELEMENT_NODE) {
            NodeList children = node.getChildNodes();
            for (int i = 0; i < children.getLength(); i++) {
                Node child = children.item(i);
                
                if (child.getNodeType() == Node.TEXT_NODE) {
                    String textContent = child.getTextContent().trim();
                    if (!textContent.isEmpty()) {
                        html.append("<tr><td>").append(textContent).append("</td></tr>");
                    }
                } else {
                    
                    html.append("<tr><td>");
                    html.append("<strong>").append(child.getNodeName()).append(":</strong> ");
                    processNode(child, html); 
                    html.append("</td></tr>");
                }
            }
        }
    }
}
