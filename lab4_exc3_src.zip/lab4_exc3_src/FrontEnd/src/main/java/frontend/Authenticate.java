package frontend;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import java.io.UnsupportedEncodingException;
import java.security.Key;
import java.util.AbstractMap;
import java.util.Date;
import java.util.Map.Entry;

public class Authenticate {

    private final SignatureAlgorithm signatureAlgorithm;
    private final Key signingKey;

    public Authenticate() {
        signatureAlgorithm = SignatureAlgorithm.HS256;
        
        signingKey = Keys.secretKeyFor(SignatureAlgorithm.HS256); // Generates a secure 256-bit key
    }

    public String createJWT(String issuer, String subject, long ttlMillis) {
        long nowMillis = System.currentTimeMillis();
        Date now = new Date(nowMillis);
        // Set the JWT Claims
        JwtBuilder builder = Jwts.builder()
                .setIssuedAt(now)
                .setSubject(subject)
                .setIssuer(issuer)
                .signWith(signingKey, signatureAlgorithm); // Sign with the secure key

        // If it has been specified, let's add the expiration
        if (ttlMillis > 0) {
            long expMillis = nowMillis + ttlMillis;
            Date exp = new Date(expMillis);
            builder.setExpiration(exp);
        }

        // Builds the JWT and serializes it to a compact, URL-safe string
        return builder.compact();
    }

    public Entry<Boolean, String> verify(String jwt) throws UnsupportedEncodingException {
        try {
            Jws<Claims> jws = Jwts.parserBuilder()
                    .setSigningKey(signingKey) 
                    .build()
                    .parseClaimsJws(jwt);

            
            String username = jws.getBody().getSubject();

           
            return new AbstractMap.SimpleEntry<>(true, username);
        } catch (JwtException ex) {
            
            throw new UnsupportedEncodingException("JWT verification failed: " + ex.getMessage());
        }
    }
}
