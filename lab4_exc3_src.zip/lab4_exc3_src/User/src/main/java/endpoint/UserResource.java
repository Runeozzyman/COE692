package endpoint;

import business.UserService;
import helper.UserXML;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.StringWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

@Path("users") 
public class UserResource {

    private UserService userService = new UserService();

    public UserResource() {
    }

    @GET
    @Produces(MediaType.APPLICATION_XML + ";charset=utf-8")
    public String getUsersXml() { 
        UserXML userXML = userService.getAllUsers();

        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(UserXML.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            StringWriter sw = new StringWriter();
            jaxbMarshaller.marshal(userXML, sw);

            return sw.toString();
        } catch (JAXBException ex) {
            Logger.getLogger(UserResource.class.getName()).log(Level.SEVERE, null, ex);
            return "error happened";
        }
    }
}
