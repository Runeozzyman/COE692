package business;

import helper.UserXML; 
import java.util.ArrayList;
import java.util.List;
import persistence.user_CRUD; 
import helper.User; 

public class UserService {

    public UserXML getAllUsers() {
        
        UserXML inst = new UserXML();
        
        List<User> users = user_CRUD.getAllUsers(); 
        UserXML userXML = new UserXML(); 
        userXML.setUsers(users);
        return userXML;
    }

 
}